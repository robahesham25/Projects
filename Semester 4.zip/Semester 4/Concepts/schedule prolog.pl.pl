ta_slot_assignment([],[],_).
ta_slot_assignment([H|T],[H1|T1],Name):- ta(N,L)=H , 
                                         N==Name , 
										 NL is L-1,
										 NL>0,
										 H1= ta(N,NL), 
										 ta_slot_assignment(T,T1,Name).
ta_slot_assignment([H|T],[H1|T1],Name):- ta(N,L)=H , 
                                         N==Name , 
										 NL is L-1,
										 NL=0,
										 H1= ta(N,0), 
										 ta_slot_assignment(T,T1,Name),!. 
ta_slot_assignment([H|T],[H1|T1],Name):- ta(N,L)=H ,
                                         N\==Name ,
										 H1= ta(N,L),
										 ta_slot_assignment(T,T1,Name).
										 
get_names([],[]).
get_names([H1|T1],[H|T]):-ta(N,_)=H1,
                            H=N,
						    get_names(T1,T).
						  
updated(L,[],L):-!.						  
updated(TAs,[H|T],Res):-!,ta_slot_assignment(TAs,R,H),
                         updated(R,T,Res).				
											

comb(0,_,[]).
comb(N,[X|T],[X|Comb]):-N>0,N1 is N-1,comb(N1,T,Comb).
comb(N,[_|T],Comb):-N>0,comb(N,T,Comb).
											
slot_assignment(LabsNum,TAs,RemTAs,Assignment):-get_names(TAs,R),
                                                comb(LabsNum,R,Assignment),
                                                updated(TAs,Assignment,RemTAs).

remove_duplicates([],[]).
remove_duplicates([H | T], List) :-member(H, T),
                                   remove_duplicates( T, List).
remove_duplicates([H|T], [H|T1]) :- \+member(H,T),
                                     remove_duplicates( T,T1).

count_occ([],_,0).	
count_occ([X|T],X,C):- count_occ(T,X,C1),
					   C is C1+1.				
count_occ([H|T],X,C):-H\=X,
                      count_occ(T,X,C).

count([],_,_).
count([H|T],L,Max):-count_occ(L,H,C),
                    C=<Max,
					count(T,L,Max).

max_slots_per_day(DaySched,Max):- flatten(DaySched,R),
                                  remove_duplicates(R,ND),
								  count(ND,R,Max).												
																			   
day_schedule([],L,L,[]).							 
day_schedule([H|T],TAs,RemTAs,[H1|T1]):-slot_assignment(H,TAs,R,H1),
                                         day_schedule(T,R,RemTAs,T1).
										
week_schedule([],_,_,[]).										
week_schedule([H|T],TAs,DayMax,[H1|T1]):- day_schedule(H,TAs,Ntas,H1),
                                          max_slots_per_day(H1,DayMax),
										  week_schedule(T,Ntas,DayMax,T1).
